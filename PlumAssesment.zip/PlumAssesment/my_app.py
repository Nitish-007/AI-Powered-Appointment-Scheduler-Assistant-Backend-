import os
import io
import cv2
import numpy as np
import easyocr
import docx
import fitz
import joblib
import re
import pytz
import parsedatetime as pdt
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, HTTPException
from typing import Optional, Dict

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from gliner import GLiNER

# ---------------- Environment ----------------
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

# ---------------- FastAPI App ----------------
app = FastAPI(title="Appointment NLP API")

# ---------------- Initialize Models ----------------
ocr_reader = easyocr.Reader(['en'], gpu=False)
gliner_model = GLiNER.from_pretrained("urchade/gliner_small").to("cpu")

# ---------------- Intent Classifier ----------------
class IntentClassifier:
    def __init__(self, model_path="intent_model.pkl", vec_path="vectorizer.pkl"):
        self.model_path = model_path
        self.vec_path = vec_path
        self.model = None
        self.vectorizer = None
        if os.path.exists(model_path) and os.path.exists(vec_path):
            self.model = joblib.load(model_path)
            self.vectorizer = joblib.load(vec_path)

    def train_default(self):
        texts = [
            "Book dentist next Friday at 3pm",
            "Cancel my doctor appointment",
            "Remind me about cardiologist visit tomorrow",
            "Dentist is very good"
        ]
        labels = [
            "appointment_request",
            "cancellation",
            "reminder",
            "not_related"
        ]
        self.vectorizer = TfidfVectorizer()
        X = self.vectorizer.fit_transform(texts)
        self.model = LogisticRegression(max_iter=1000)
        self.model.fit(X, labels)
        joblib.dump(self.model, self.model_path)
        joblib.dump(self.vectorizer, self.vec_path)

    def predict(self, text):
        if not self.model or not self.vectorizer:
            self.train_default()
        X = self.vectorizer.transform([text])
        pred = self.model.predict(X)[0]
        conf = max(self.model.predict_proba(X)[0])
        return {"intent": pred, "intent_confidence": round(float(conf), 2)}

intent_classifier = IntentClassifier()

# ---------------- OCR / Extraction ----------------
def ocr_image(file_bytes: bytes) -> (str, float):
    image_np = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(image_np, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Cannot decode image")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray_resized = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    thresh = cv2.adaptiveThreshold(gray_resized, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 2)
    kernel = np.ones((2, 2), np.uint8)
    thresh = cv2.dilate(thresh, kernel, iterations=1)
    results = ocr_reader.readtext(thresh, detail=1, allowlist='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@:/. ')
    text = " ".join([r[1] for r in results])
    confidence = float(np.mean([r[2] for r in results])) if results else 0.5
    return text, round(confidence, 2)

def extract_pdf(file_bytes: bytes) -> str:
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    return "".join(page.get_text() for page in doc).strip()

def extract_docx(file_bytes: bytes) -> str:
    with io.BytesIO(file_bytes) as docx_stream:
        doc = docx.Document(docx_stream)
        return " ".join([p.text for p in doc.paragraphs])

# ---------------- GLiNER Entity Extraction ----------------
def normalize_text(text: str) -> str:
    corrections = {"nxt": "next", "tmrw": "tomorrow", "@": "at"}
    for wrong, right in corrections.items():
        text = text.replace(wrong, right)
    return text

def extract_entities_gliner(text: str) -> Dict:
    text = normalize_text(text)
    labels = ["date", "time", "department"]
    entities = gliner_model.predict_entities(text, labels)

    # Try to expand date to include previous token if it's a modifier
    date_phrase = next((e["text"] for e in entities if e["label"].lower() == "date"), None)
    if date_phrase:
        # Include "next" if it precedes the date
        match = re.search(r"(next|this|following)\s+" + re.escape(date_phrase), text, re.IGNORECASE)
        if match:
            date_phrase = match.group(0)

    time_phrase = next((e["text"] for e in entities if e["label"].lower() == "time"), None)
    department = next((e["text"] for e in entities if e["label"].lower() == "department"), None)

    # fallback rule-based for department
    if not department:
        for keyword in ["dentist", "doctor", "cardiologist", "dermatologist"]:
            if keyword in text.lower():
                department = keyword
                break
    return {"entities": {"date_phrase": date_phrase, "time_phrase": time_phrase, "department": department}, "entities_confidence": 0.9}

# ---------------- Normalization ----------------
def normalize_entities(entities_dict: Dict) -> Dict:
    date_phrase = entities_dict.get("date_phrase")
    time_phrase = entities_dict.get("time_phrase")
    department = entities_dict.get("department")
    if not date_phrase or not time_phrase or not department:
        return {"status": "needs_clarification", "message": "Ambiguous date/time or department"}
    datetime_text = f"{date_phrase} {time_phrase}"
    cal = pdt.Calendar()
    base = datetime.now()
    time_struct, parse_status = cal.parse(datetime_text, base)
    if parse_status == 0:
        return {"status": "needs_clarification", "message": "Could not parse date/time"}
    dt = pytz.timezone("Asia/Kolkata").localize(datetime(*time_struct[:6]))
    return {"normalized": {"date": dt.strftime("%Y-%m-%d"), "time": dt.strftime("%H:%M"), "tz": "Asia/Kolkata"}, "normalization_confidence": 0.95, "status": "ok"}

# ---------------- API Endpoint ----------------
from fastapi import Body

@app.post("/process_appointment")
async def process_appointment(
    text: Optional[str] = Body(None), 
    file: Optional[UploadFile] = File(None)
):
    if text:
        extracted_text = normalize_text(text)
        extracted_text = re.sub(r'\b(\d{1,2})[.:](\d{2})\b', r'\1:\2', extracted_text)
        extraction_conf = 0.95
    elif file:
        contents = await file.read()
        fname = file.filename.lower()
        if fname.endswith(".pdf"):
            extracted_text = extract_pdf(contents)
            extracted_text = re.sub(r'\b(\d{1,2})[.:](\d{2})\b', r'\1:\2', extracted_text)
            extraction_conf = min(0.9, len(extracted_text)/5000)
        elif fname.endswith(".docx"):
            extracted_text = extract_docx(contents)
            extracted_text = re.sub(r'\b(\d{1,2})[.:](\d{2})\b', r'\1:\2', extracted_text)
            extraction_conf = min(0.9, len(extracted_text)/5000)
        elif fname.endswith((".png", ".jpg", ".jpeg")):
            extracted_text, extraction_conf = ocr_image(contents)
            extracted_text = re.sub(r'\b(\d{1,2})[.:](\d{2})\b', r'\1:\2', extracted_text)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type")
    else:
        raise HTTPException(status_code=400, detail="No input provided")

    intent_result = intent_classifier.predict(extracted_text)
    
    
    # ---------------- Multi-Appointment Extraction ----------------
    split_pattern = r'(?<=[.!?])\s+|and also|then|also'
    sentences = re.split(split_pattern, extracted_text, flags=re.IGNORECASE)
    appointments = []
    step3_entities_list = []
    step4_normalization_list = []

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue

        # Step 3: Entity Extraction
        entities_result = extract_entities_gliner(sentence)
        departments = ["dentist", "doctor", "cardiologist", "dermatologist"]
        found = [kw for kw in departments if kw in sentence.lower()]
        department = found[0] if found else entities_result["entities"].get("department")
        entities_result["entities"]["department"] = department
        
        time_phrase = entities_result["entities"].get("time_phrase")
        if time_phrase:
            match = re.match(r'(\d{1,2}:\d{2}\s*(am|pm)?)', time_phrase.lower())
            if match:
                entities_result["entities"]["time_phrase"] = match.group(1)

        step3_entities_list.append(entities_result)

        # Step 4: Normalization
        norm_result = normalize_entities(entities_result["entities"])
        step4_normalization_list.append(norm_result)

        if norm_result.get("status") == "ok":
            appointments.append({
                "department": entities_result["entities"]["department"].capitalize() if entities_result["entities"]["department"] else None,
                **(norm_result.get("normalized", {}))
            })

    final_output = {
        "appointments": appointments,
        "status": "ok" if appointments else "needs_clarification"
    }

    # ---------------- Return ----------------
    return {
        "step1": {"raw_text": extracted_text, "confidence": round(extraction_conf, 2)},
        "step2_intent": intent_result,
        "step3_entities": step3_entities_list,
        "step4_normalization": step4_normalization_list,
        "step5_final": final_output
    }

# ---------------- Run Uvicorn + Ngrok ----------------
if __name__ == "__main__":
    import uvicorn
    from pyngrok import ngrok

    port = 8000
    # Start ngrok tunnel
    public_url = ngrok.connect(port)
    print(" * ngrok tunnel:", public_url)

    # Start uvicorn server
    uvicorn.run(app, host="0.0.0.0", port=port)
